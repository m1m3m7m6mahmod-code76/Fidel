import 'package:flutter/material.dart';

void main() => runApp(const FidelApp());

class FidelApp extends StatelessWidget {
  const FidelApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'فیدل | فروشگاه تشک',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF12345A)), useMaterial3: true, fontFamily: 'Roboto'),
    home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
  );
}

class Mattress {
  final String name;
  final String warranty;
  final String type;
  final Map<int, double> economy;
  final Map<int, double> plus;
  const Mattress(this.name, this.warranty, this.type, this.economy, this.plus);
  double? price(String tier, int size) => (tier == 'PLUS' ? plus : economy)[size];
}

const mattresses = <Mattress>[
  Mattress('آسوده', '۲ سال', 'فنر متصل بونل', {90:13.95,120:18.3,140:20.7,160:23.2,180:25.5}, {90:17.8,120:23.1,140:26.8,160:29.5,180:32.3}),
  Mattress('آسایش', '۳ سال', 'فنر متصل بونل', {90:17.36,120:23.2,140:27,160:29.26,180:32}, {90:23.7,120:30.8,140:36.5,160:38.7,180:41.6}),
  Mattress('آرامش', '۴ سال', 'فنر میکرو + پد', {90:26.25,120:33.9,140:40.5,160:43.95,180:48.3}, {90:36.5,120:47.1,140:57.5,160:60.8,180:66.5}),
  Mattress('تاپ', '۵ سال', 'فنر میکرو', {90:26.7,120:34.2,140:41,160:44.2,180:48.9}, {90:36.8,120:48.9,140:54.5,160:63,180:69}),
  Mattress('کلاسیک', '۶ سال', 'فنر میکرو + پد', {90:29,120:36.98,140:43.47,160:47.38,180:51.84}, {90:40.5,120:51.3,140:63.6,160:70,180:74.5}),
  Mattress('المپیک', '۷ سال', 'فنر میکرو', {90:29.29,120:39.42,140:45.36,160:49.4,180:54.27}, {90:43,120:51.9,140:66.5,160:71.5,180:79.9}),
  Mattress('ریلکس', '۸ سال', 'فنر میکرو + پد', {90:35.8,120:48.14,140:55.39,160:60,180:65.68}, {90:46.5,120:61.8,140:73.2,160:79.7,180:87.5}),
  Mattress('آسمان', '۱۰ سال', 'فنر پاکتی + پد', {90:52.2,120:64.67,140:74.38,160:84.68,180:93.67}, {90:69.6,120:84.5,140:99.5,160:113.4,180:124}),
  Mattress('پلی‌تاپ', '۹ سال', 'بدون فنر + پد', {90:41,120:51,140:61,160:66.3,180:70.98}, {90:53.8,120:71.2,140:83.5,160:90.5,180:98.5}),
  Mattress('مدیکال', '۱۵ سال', 'تمام‌اسفنجی + پد', {90:58.48,120:71.74,140:87,160:94,180:110.7}, {90:91.7,120:114,140:133,160:154.7,180:174}),
];

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab=0; String tier='ECONOMY'; int size=160;
  @override Widget build(BuildContext context) {
    final pages=[_catalog(), const AssistantPage(), const OrdersPage()];
    return Scaffold(appBar: AppBar(title: const Text('فیدل',style: TextStyle(fontWeight: FontWeight.bold)), centerTitle: true, actions:[IconButton(onPressed:()=>_showInfo(),icon:const Icon(Icons.info_outline))]),
      body: pages[tab], bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.bed_outlined),label:'محصولات'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline),label:'مشاور هوشمند'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),label:'سفارش‌ها') ]));
  }
  Widget _catalog()=>Column(children:[Padding(padding:const EdgeInsets.fromLTRB(16,8,16,4),child:Container(width:double.infinity,padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFF12345A),borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('خواب راحت، انتخاب مطمئن',style:TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),SizedBox(height:6),Text('مدل مناسب خودتان را از میان تشک‌های فیدل پیدا کنید',style:TextStyle(color:Colors.white70))]))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),child:Row(children:[Expanded(child:SegmentedButton<String>(segments:const [ButtonSegment(value:'ECONOMY',label:Text('ECONOMY')),ButtonSegment(value:'PLUS',label:Text('PLUS'))],selected:{tier},onSelectionChanged:(v)=>setState(()=>tier=v.first))),const SizedBox(width:10),DropdownButton<int>(value:size,items:[90,120,140,160,180].map((v)=>DropdownMenuItem(value:v,child:Text('$v × ۲۰۰'))).toList(),onChanged:(v)=>setState(()=>size=v!))])),
    Expanded(child:ListView.builder(padding:const EdgeInsets.fromLTRB(16,4,16,16),itemCount:mattresses.length,itemBuilder:(c,i){final m=mattresses[i];final p=m.price(tier,size);return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:Container(width:54,height:54,decoration:BoxDecoration(color:const Color(0xFFE8EEF5),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.bed,color:Color(0xFF12345A),size:30)),title:Text('${m.name} ${tier=='PLUS'?'پلاس':''}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${m.type} • ضمانت ${m.warranty}\n${p==null?'برای این ابعاد قیمت ثبت نشده':'${p.toStringAsFixed(2)} میلیون تومان'}'),isThreeLine:true,trailing:const Icon(Icons.chevron_left),onTap:()=>_detail(m,p)));}))]);
  void _detail(Mattress m,double? p)=>showModalBottomSheet(context:context,isScrollControlled:true, builder:(c)=>Directionality(textDirection:TextDirection.rtl,child:Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${m.name} ${tier=='PLUS'?'پلاس':''}',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:8),Text('سری: $tier'),Text('ابعاد: $size × ۲۰۰ سانتی‌متر'),Text('نوع ساخت: ${m.type}'),Text('ضمانت: ${m.warranty}'),Text('قیمت: ${p==null?'استعلام شود':'${p.toStringAsFixed(2)} میلیون تومان'}'),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>Navigator.pop(c),icon:const Icon(Icons.shopping_cart_outlined),label:const Text('افزودن به سبد خرید (نسخه نمایشی)')))]))));
  void _showInfo()=>showAboutDialog(context:context,applicationName:'فیدل',applicationVersion:'نسخه اولیه نمایشی',children:[const Text('این نسخه نمونه اولیه رابط کاربری است. ثبت سفارش واقعی، درگاه پرداخت و اتصال مدیریتی هنوز پیاده‌سازی نشده‌اند.')]);
}

class AssistantPage extends StatefulWidget { const AssistantPage({super.key}); @override State<AssistantPage> createState()=>_AssistantPageState(); }
class _AssistantPageState extends State<AssistantPage>{final controller=TextEditingController();final messages=<String>['سلام، به مشاور هوشمند فیدل خوش آمدید 🌹\nبرای پیشنهاد تشک مناسب، لطفاً بفرمایید تشک را برای یک نفر می‌خواهید یا دونفره؟'];void send(){final s=controller.text.trim();if(s.isEmpty)return;setState(()=>messages.add('شما: $s'));controller.clear();setState(()=>messages.add('مشاور فیدل: ممنون از توضیحتان. برای پیشنهاد دقیق‌تر، وزن تقریبی استفاده‌کننده و میزان سفتی دلخواهتان را هم بفرمایید.'));} @override Widget build(BuildContext context)=>Column(children:[Expanded(child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:messages.length,itemBuilder:(c,i)=>Align(alignment:i==0||messages[i].startsWith('مشاور')?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(14),constraints:const BoxConstraints(maxWidth:320),decoration:BoxDecoration(color:i==0||messages[i].startsWith('مشاور')?const Color(0xFFE8EEF5):const Color(0xFF12345A),borderRadius:BorderRadius.circular(16)),child:Text(messages[i],style:TextStyle(color:i==0||messages[i].startsWith('مشاور')?Colors.black87:Colors.white)))))),SafeArea(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:controller,decoration:const InputDecoration(hintText:'پیام خود را بنویسید...',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:send,icon:const Icon(Icons.send))]))) ]);}
class OrdersPage extends StatelessWidget {const OrdersPage({super.key});@override Widget build(BuildContext context)=>const Center(child:Padding(padding:EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.receipt_long_outlined,size:60,color:Color(0xFF12345A)),SizedBox(height:12),Text('هنوز سفارشی ثبت نشده است',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),SizedBox(height:6),Text('پس از فعال‌شدن ثبت سفارش، وضعیت خریدهای شما در این قسمت نمایش داده می‌شود.',textAlign:TextAlign.center)])));}
